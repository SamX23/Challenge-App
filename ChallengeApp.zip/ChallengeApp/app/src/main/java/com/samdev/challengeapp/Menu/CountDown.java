package com.samdev.challengeapp.Menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.samdev.challengeapp.R;

public class CountDown extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_count_down);
    }
}
