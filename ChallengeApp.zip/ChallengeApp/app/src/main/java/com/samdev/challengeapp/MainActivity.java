package com.samdev.challengeapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.samdev.challengeapp.Menu.Calculator;
import com.samdev.challengeapp.Menu.CountDown;
import com.samdev.challengeapp.Menu.FormActivity;
import com.samdev.challengeapp.Menu.InputNameButton;
import com.samdev.challengeapp.Menu.SettingActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.login_act) {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return true;
        }
        // Setting activity example
        if (id == R.id.action_settings) {
            Intent setting = new Intent(this, SettingActivity.class);
            startActivity(setting);
            return true;
        }

        // Form activity Example
        if (id == R.id.action_form) {
            Intent form = new Intent(this, FormActivity.class);
            startActivity(form);
            return true;
        }

        // Calculator activity Example
        if (id == R.id.action_calc) {
            Intent calc = new Intent(this, Calculator.class);
            startActivity(calc);
            return true;
        }

        // Countdown activity Example
        if (id == R.id.action_count_down) {
            Intent countdown = new Intent(this, CountDown.class);
            startActivity(countdown);
            return true;
        }

        // Text Input activity Example
        if (id == R.id.action_input) {
            Intent actInp = new Intent(this, InputNameButton.class);
            startActivity(actInp);
            return true;
        }

        if (id == R.id.close) {
            System.exit(0);
        }

        return super.onOptionsItemSelected(item);
    }
}